import google.generativeai as genai
import gradio as gr
import numpy as np
import soundfile as sf
import time
import uuid

genai.configure(api_key="AIzaSyAK__PhUk2GU6rdjI868aKRuYW5QTvZ5XI")

PROMPT_DEFAULT = """
You are a native English speaker and expert linguist specializing in pronunciation coaching. Your task is to analyze an audio recording of spoken English, compare the audio with the phrase stated in the input, and provide a detailed pronunciation assessment.

Input:
You will receive two items:
(1) An audio file containing spoken English. This could be a single word, a phrase, a sentence, or a longer passage.
(2) A word or phrase to be used for comparison with the audio.

Goal:
Compare each detected word with the word or phrase provided in the input. If the audio does not contain the phrase from the input, write:
"The audio does not contain the phrase."

Task: Analyze the provided audio and perform the following assessments:

Phrase Detection: Identify the specific phrase spoken in the audio, using the input as a reference. If the audio contains multiple words or phrases, analyze each separately.

Comparison: Compare each detected word with the phrase provided in the input. If the audio does not contain the input phrase, write: "The audio does not contain the phrase."

Detailed Breakdown of Problem Areas: For any phrase with a pronunciation rating below 100%, provide a detailed breakdown of specific pronunciation issues. For example, instead of saying “the ‘th’ sound was wrong,” say, “the speaker pronounced /t/ instead of the voiced /ð/ sound in the word ‘this.’" Using IPA (International Phonetic Alphabet) is optional but can be helpful. Consider the following pronunciation aspects:
Vowel sounds: Are they pronounced correctly in terms of length and quality? Are diphthongs or monophthongs used where appropriate?
Consonant sounds: Are they articulated correctly? Are they voiced or voiceless as needed? Are there any substitutions, omissions, or additions?
Stress: Is the stress placed on the correct syllable(s) within the word or phrase?
Intonation: Does the intonation rise and fall naturally, reflecting proper sentence structure and meaning? (If the audio contains more than a single word.)
Linking: Are words connected smoothly where appropriate? (If the audio contains more than a single word.)
Undetected Words: Were any words missing from the input phrase?


Recommendations for Improvement: For each problem area, provide specific, actionable recommendations. These may include articulation techniques, minimal pair exercises, or suggested resources for further practice.

Overall Pronunciation Rating: Assign a percentage-based rating for the pronunciation accuracy of each identified word/phrase. 100% represents native-like pronunciation, while 0% indicates completely unintelligible pronunciation and between 0% and 90% evaluates based on pronunciation, recommendations for Improvement, and the detailed breakdown of problem areas given above. Justify your rating by explaining the specific aspects of pronunciation that contributed to the score.

Output Format: Your output should be clear, structured, and easy to understand. A suggested format is:

Phrase provided in the input:
[Phrase from the input]

Phrase detected in the audio:
[Phrase detected in the audio]

Comparison:
Comparison of the audio with the input phrase.
If the audio does not contain the input phrase, write:
"The audio does not contain the phrase."

Analysis:
[Detailed explanation of pronunciation accuracy and justification for the rating.]

Overall Pronunciation Rating:
[Percentage]% calculated (or 0% if the phrase was not present)

Analysis:
[Detailed explanation of pronunciation accuracy and justification for the rating.]

Problem Areas:
[Issue 1] – [Description and impact on intelligibility.]
Example: The /θ/ sound in "think" was pronounced as /t/, making it sound like "tink."
[Issue 2] – [Description and impact on intelligibility.]
Example: The stress was placed on the second syllable of "comfortable," making it difficult to understand.
[And so on for each problem area]

Recommendations for Improvement:
[Recommendation for Issue 1]
Example: Practice the /θ/ sound by placing your tongue lightly between your teeth and exhaling. Listen to recordings of native speakers pronouncing "think" and try to mimic the correct articulation.
[Recommendation for Issue 2]
Example: Consult a dictionary to confirm the correct stress pattern for "comfortable." Practice saying the word with the stress on the first syllable.
[And so on for each problem area]

Important Considerations:
Be objective and specific in your analysis.
Provide constructive feedback that helps the speaker improve.
Consider the context of spoken English (e.g., formal vs. informal), but the target pronunciation should be standard, clear, and easily understood.

Examples:

Input:
Audio attached
Word/Phrase to compare with the audio: "playing soccer with my friends"
Output:
Word/Phrase provided in the input: playing soccer with my friends
Word/Phrase detected in the audio: playing soccer with my pets

Comparison:
The detected phrase is "playing soccer with my pets," which differs from the input phrase.

Overall Pronunciation Rating: 80%

Analysis:
The pronunciation of "playing" is generally clear. However, some words detected in the audio differ from those in the input phrase.

Problem Areas:

Incorrect word substitution: The speaker said "pets" instead of "friends."
Recommendations for Improvement:

Focus on distinguishing the sounds in "friends" versus "pets." The /fr/ cluster in "friends" requires a clearer articulation of the /r/ sound. Practice minimal pairs like "friends" vs. "pets" to improve differentiation.

Input:
Audio attached
Phrase to compare with the audio: "good liquor"
Output:
Phrase provided in the input: "good liquor"
Phrase detected in the audio: "good liquid"

Comparison:
This audio does not contain the complete phrase "good liquor". I have detected only good but liquor was not detected

Overall Pronunciation Rating: 30%

Analysis:
N/A

Problem Areas:
N/A

Recommendations for Improvement:
N/A


Input:
Audio attached
the phrase to compare the audio: "{}"

Output:
"""


def upload_audio(audio):
    sample_rate, data = audio
    data = np.array(data)
    guid_string = str(uuid.uuid4())
    filename = f"media/{guid_string}.wav"

    # Handle stereo vs. mono correctly.  Gradio's Audio component can return
    # either.
    if data.ndim == 2:  # stereo
        data = data.T  # Transpose it to channels last for soundfile
    elif data.ndim != 1:  # neither
        return "Unexpected audio data format"

    print(sample_rate)
    sf.write(filename, data, sample_rate)
    print("audio file uploaded")
    ref = genai.upload_file(path=filename)
    print(ref)
    return ref


def create_prompt(word_phrase, prompt):
    return prompt.format(word_phrase)


def evaluate_audio_pronunciation(audio_file_id, prompt, model="gemini-2.0-flash"):
    prompt = [
        prompt, audio_file_id]
    model = genai.GenerativeModel(model)
    response = model.generate_content(
        contents=prompt,)
    total_token_count = response.usage_metadata.total_token_count
    return response.text, response.usage_metadata.prompt_token_count, total_token_count


def orchestation(audio, prompt, word_phrase, model):
    start_time = time.time()
    audio_file_id = upload_audio(audio)
    prompt = create_prompt(word_phrase, prompt)
    response, input_tokens, total_tokens = evaluate_audio_pronunciation(
        audio_file_id, prompt, model)
    end_time = time.time()
    return response, f"{end_time - start_time} seconds", input_tokens, total_tokens, model


ui_blocks = gr.Blocks()

input_audio = gr.Audio(
    sources=["microphone", "upload"],
    waveform_options=gr.WaveformOptions(
        waveform_color="#01C6FF",
        waveform_progress_color="#0066B4",
        skip_length=2,
        show_controls=False,
    ),
)

get_prompt_ui_block = gr.Interface(
    fn=orchestation,
    inputs=[input_audio,
            gr.Textbox(label="Write your prompt...",
                       value=PROMPT_DEFAULT, lines=20),
            gr.Textbox(label="Word or Phase", lines=1),
            gr.Radio(["gemini-1.5-flash-8b", "gemini-2.0-flash", "gemini-2.0-flash-lite-preview-02-05", "gemini-1.5-flash"], info="Models")],
    outputs=[gr.Textbox(label="Response"),
             gr.Textbox(label="Time"),
             gr.Textbox(label="Input Tokens"),
             gr.Textbox(label="Total Tokens"),
             gr.Textbox(label="Model"),],
    allow_flagging="never")


with ui_blocks:
    gr.TabbedInterface(
        [get_prompt_ui_block],
        ["Evaluate Audio Pronunciation"],
    )

if __name__ == "__main__":
    ui_blocks.launch()
