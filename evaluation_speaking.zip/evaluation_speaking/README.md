---
title: Evaluation Speaking
emoji: 💻
colorFrom: red
colorTo: yellow
sdk: gradio
sdk_version: 5.15.0
app_file: app.py
pinned: false
license: mit
short_description: Evaluation Speaking
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
